using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class FabunacciSequence : MonoBehaviour
{   private int firstNumber;
    private int secondNumber;
   

    public TMP_Text number1Display;
    public TMP_Text number2Display;


    public GameObject firstCube;

    public GameObject secondCube;
    public GameObject thirdCube;

    private TMP_Text number3Display;

    private int number1, number2;

    private GameObject spawnedCube;

    public GameObject playerCamera;

    public AudioSource buttonClick;

    [SerializeField]private int[] thirdNumber;
    private int counter = 0;

    
    // Start is called before the first frame update
    void Start()
    {

        //setting numbers up for use
        firstNumber = 1;

        secondNumber = 1;

        //making array limit
        thirdNumber = new int[999];
        //making first number 0
        thirdNumber[counter] = 0;

        // pre-initializing the first number and second number
        number1Display.SetText(firstNumber.ToString());
        number2Display.SetText(secondNumber.ToString());
        
        
    }

    // Update is called once per frame
    void Update()
    {
        
        
       //Debug.Log(firstNumber + "_" + secondNumber + "_" + thirdNumber[counter]);

       Debug.Log(counter);
    
        
    }


   private float offset2 = 0;

   private int number = 1;
    public void NextNumber(){
       //soundPlay
       buttonClick.Play();
       //Counter+1
       counter += 1;

       //turning the offset to the required amount after the first button press
       number = (number *counter) - 1;
       if(thirdNumber [1] > 1){
        

        offset2 = 16.6f;
       }

        
        //the fibonacci sequence maths/equation
        thirdNumber[counter] = firstNumber + secondNumber;
    
        firstNumber = secondNumber;

        secondNumber = thirdNumber[counter];


        
        // I was getting negative numbers at some point for some reason, so I made these if statements to prevent that 
        //from happening
        if(firstNumber < 0 ){
            firstNumber *= -1; 

        }
        if(secondNumber < 0 ){
            secondNumber *= -1; 
        }
        if(thirdNumber[counter]< 0 ){
            thirdNumber[counter]*= -1; 
        }

        // spawning in the sumof the last two numbers, whilst naming instantiated clones to differentiate the objects
        // in order to give/keep their own respective numebers
        thirdCube = Instantiate(thirdCube, new Vector3((thirdCube.transform.position.x + offset2),thirdCube.transform.position.y, thirdCube.transform.position.z), thirdCube.transform.rotation);
        thirdCube.name = "newSequence" + counter;
        
        
        
       
            //Getting the text component in the obejct's children (only one child with text component)
            //and giving them their number
      
            number3Display = GameObject.Find("newSequence"+ (counter)).GetComponentInChildren<TMP_Text>();
            number3Display.SetText(thirdNumber[counter].ToString());
            
            //making the camera focus the new spawned in cube
            spawnedCube = GameObject.Find("newSequence"+counter);
            playerCamera.transform.position = new Vector3(spawnedCube.transform.position.x, 1, -40);
        
        

        
    }

        // This is code that was not used but a feature I had in mind when making this app, it was not used to it not
        //being polished enough in the time constraint given. its a zoom in and zoom out mechanic using buttons
        public void zoomOut(){
        if(playerCamera.transform.position.z > -50){
        playerCamera.transform.position = new Vector3(spawnedCube.transform.position.x, 1, -10);
        }
        else{Debug.Log("i did nothing");}
    }
        //same goes for the code below
    public void zoomIn(){
        if(playerCamera.transform.position.z < -10){
        playerCamera.transform.position = new Vector3(playerCamera.transform.position.x, 1, +10);
        }
        else{Debug.Log("i did nothing");}
    }
}
