using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playSound : MonoBehaviour
{   //taking audio from an object to play for buttons
    public AudioSource buttonClick;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    public void soundPlay()
    {
        buttonClick.Play();
    }
}
