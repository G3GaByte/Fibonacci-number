using System.Collections;
using System.Collections.Generic;
using UnityEngine;



// This is attempted code that I wasnt able to implement in the timeframe given, I kept it in case
// in case you would like to see my attempts. This feature was allowing the player to pan between 
// the spawned numbers at any given time using buttons
public class CameraPan : MonoBehaviour
{   public GameObject playerCamera;

    private Rigidbody cameraRb;

    private int counter;

    void Start(){
        cameraRb = playerCamera.GetComponent<Rigidbody>();
        counter = 0;
    }

    void Update(){Debug.Log(counter);}
    public void CameraLeftPan(){
        
        if(counter> -6){

        cameraRb.AddForce(Vector3.right*counter, ForceMode.Impulse);
        
        counter = counter - 2;
        }
        else{}

        
    }

    public void CameraRightPan(){
        
        if(counter < 6){

        cameraRb.AddForce(-Vector3.right*counter, ForceMode.Impulse);
        counter = counter + 2;
        }
        
        else{

            
        }

        

    }
}
