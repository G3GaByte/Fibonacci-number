using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ResetGame : MonoBehaviour
{ 
    //this script is called 'reset game' but essentially its just a sceneloader
    
    public string SceneName;
    // Start is called before the first frame update
    public void ResetSequence(){

        SceneManager.LoadScene(SceneName);

    }
    //used the exit button code here as well
    public void quitGame(){

        Application.Quit();

    }
}
